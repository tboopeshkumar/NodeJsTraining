
before(function(done){
  this.redis.flushall(done);
});
