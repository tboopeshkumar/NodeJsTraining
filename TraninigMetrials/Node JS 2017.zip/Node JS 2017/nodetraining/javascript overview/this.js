﻿//5 shares of 'this'

//The value of this  depend on how a functioin is invoked

// 1. Invoke as a function
function foo() {
    foo(); // this=== window
    var bar = function () { };
    bar();//  this===window
}

//2. Invoke as  a method
function foo() {
    return this;
}
foo(); // this ===window
var bar = { 'foo': foo };
// invoke as a method of 'bar'
bar.foo; // this===bar


//3. Invoke as constructor
function Foo() {
    this.bar = function () {
        return this;
    }
}
var foo = new Foo();
console.log(foo);//foo
console.log(foo.bar() instanceof Foo);//true

// Invoke by passing THIS
function foo() {
    console.log(this);// this ===element
    console.log(arguments);// 'a', 'b', 'c'
}
var element = document.querySelector('#foo');
element.addEventListener('click', function (e) {
    console.log(this);//element
    console.log(arguments);// e===event
    foo.call(element, 'a', 'b', 'c');
    //or
    foo.apply(element, ['a', 'b', 'c']);
})

//5. Invoke with Binding
var Foo = function () {
    this.counter = 0;
    this.inc = function () {
        this.counter += 1;
        console.log(this);
    };
};
var foo = new Foo();
var element = document.querySelector('#foo');
element.addEventListener('click', foo.inc);
element.addEventListener('click', function () { foo.inc() });
element.addEventListener('click', foo.inc.bind(foo));

