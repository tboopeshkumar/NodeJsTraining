console.log("Murthy Child Process " + process.argv[2] + " executed.");
