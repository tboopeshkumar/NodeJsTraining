﻿// failing.js
console.log('Hello!');
throw new Error('Ops!')
console.log('End!');