﻿console.log("Child Process " + process.argv[2] + " executed.");
