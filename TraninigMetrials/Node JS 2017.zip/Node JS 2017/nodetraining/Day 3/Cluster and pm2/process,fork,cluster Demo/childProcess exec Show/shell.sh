#!/bin/sh
echo "running this shell script from child_process.execFile"
# run another node process
node spawn.js
# and another
node  spawnprocess.js
