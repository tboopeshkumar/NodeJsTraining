﻿//uses server.js

var exec = require('child_process').exec;

var child = exec('node  ./server.js');
child.stdout.on('data', function (data) {
    console.log('stdout: ' + data);
});
child.stderr.on('data', function (data) {
    console.log('stdout: ' + data);
});
child.on('close', function (code) {
    console.log('closing code: ' + code);
});

//node testserver.js

// inorder to stop server , visit same page 3 times

/*
spawn:  unlike exec it launches a new process and should be used if we expect long-time communication 
with the running command. The API is a little bit different, but both methods work similar.

child_process.exec(command, [options], callback)
child_process.spawn(command, [args], [options])

spawn doesn't accept a callback and if we need to pass arguments along with the command
name we have to do this in an additional [args] array.

*/