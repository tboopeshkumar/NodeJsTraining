//Spawning Children
/**
* .spawn
*/
var spawn = require('child_process').spawn,
	pwd = spawn('pwd'),
	ls = spawn('ls', ['-G']),
	nd = spawn('node', ['spawn.js']);

pwd.stdout.setEncoding('utf8');

pwd.stdout.on('data', function(data) {
	console.log(data);
});

pwd.stderr.on('data', function(data) {
	console.log(data);
});

pwd.on('close', function(){
	console.log('closed');
});

ls.stdout.setEncoding('utf8');
	ls.stdout.on('data', function(data) {
	console.log(data);
});

nd.stdout.setEncoding('utf8');
nd.stdout.on('data', function(data) {
	console.log(data);
});

/*  Child Process Events
‘message’   - 
Transfers a message object, which is JSON, or a value. 
This can also transfer a socket or server object as an optional second parameter.

‘error’   - 
Transmits the error to the callback. This can happen when the child process
 fails to spawn,is unable to be killed, or the message transfer fails.

‘close’ - 
Happens when all of the stdio streams of the child process are completed. This will transmit
the exit code and the signal that was sent with it.

‘disconnect’ Emits when you terminate a connection by utilizing 
the .disconnect() method on the child  (or parent).

‘exit’- 
Emits after the child process ends. If the process terminated normally, 
code is the final exit code of the process, otherwise null.
If the process terminated due to receipt of a signal, signal is the
string name of the signal, otherwise null.

*/
