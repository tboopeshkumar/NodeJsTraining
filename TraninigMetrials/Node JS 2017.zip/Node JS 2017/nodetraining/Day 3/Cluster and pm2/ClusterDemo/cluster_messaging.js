var cluster = require('cluster');
var http = require('http');
var numCPUs = require('os').cpus().length;
var workers = {};
var requests = 0;

if (cluster.isMaster) {
  for (var i = 0; i < numCPUs; i++) {
    workers[i] = cluster.fork();

//Listen for messages from worker
    (function (i) {
      workers[i].on('message', function(message) {
        if (message.cmd == 'incrementRequestTotal') {
          requests++;  //Increase request total
          for (var j = 0; j < numCPUs; j++) {
            workers[j].send({
                //Send new request total to each worker
              cmd:  'updateOfRequestTotal',
              requests: requests
            });
          }
        }
      });
    })(i);  //Use closure to preserve the value of worker
  }

  cluster.on('exit', function(worker, code, signal) {
    console.log('Worker ' + worker.process.pid + ' died.');
  });
} else {
    //Listen for messages from master
  process.on('message', function(message) {
    if (message.cmd == 'updateOfRequestTotal') {
        //Update request count using master’s message
      requests = message.requests;
    }
  });

  http.Server(function(req, res) {
    res.writeHead(200);
    //Let master know request total should increase
    res.end('Worker in process ' + process.pid
      + ' says cluster has responded to ' + requests
      + ' requests.');
    process.send({cmd: 'incrementRequestTotal'});
  }).listen(8000);
}

// node cluster_message.js
// open browser and type localhost:8000  and observe message
// copy url and paste in another tab  and observe message
// repeat same and observe message