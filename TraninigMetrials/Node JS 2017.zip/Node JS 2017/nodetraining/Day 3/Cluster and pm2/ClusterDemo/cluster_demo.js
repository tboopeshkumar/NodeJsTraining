var cluster = require('cluster');
var http = require('http');
var numCPUs = require('os').cpus().length;
console.log("No. of cores in my system " + numCPUs);

if (cluster.isMaster) {
  for (var i = 0; i < numCPUs; i++) {
      cluster.fork();      
  }

  cluster.on('listening', function (worker, address) {
      console.log(worker.process.pid + ' worker is listening on localhost:8000');
  });
  cluster.on('exit', function(worker, code, signal) {
      console.log('Worker ' + worker.process.pid + ' died.');
     // cluster.fork();
  });
  cluster.on('fork', function (worker) {
      console.log(worker.process.pid + ' worker is forked');
  });
} else {
    // this will be executed 3 times on quadracore system
   console.log("created server.......")
  http.Server(function(req, res) {
    res.writeHead(200);
    res.end('I am a worker running in process ' + process.pid);
  }).listen(8000);
}
// node cluster_demo.js