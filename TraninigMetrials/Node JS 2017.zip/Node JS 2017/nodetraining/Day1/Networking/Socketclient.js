// Socket Client
var net = require('net');

// createConnection
var connection = net.createConnection(
	     {port: 8181, host:'127.0.0.1'},
        function() {
	        console.log('connection successful');
        this.write('hello .. I am murthy');
});
// when data is received from server socket , log it
connection.on('data', function(data) {
	console.log(data.toString());
});
// in case not able to create socket to server , log error
connection.on('error', function(error) {
	console.log(error);
});
// $  node socketclient.js    (start another cmd prompt)
// When socket is closed, end connection
connection.on('end', function() {
	console.log('connection ended');
});

// To run,  First run server    - node Socketserver.js
// start another instance of CMD, - node Socketclient.js