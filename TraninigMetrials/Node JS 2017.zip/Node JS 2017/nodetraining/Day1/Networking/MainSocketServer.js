// Communicating between servers

// Main Server listening for socket clients to connect
/*
A net.Socket connection, as you have seen, is a Node.js object that 
represents a TCP or UNIX socket. 

In Node.js this  means that it implements a duplex stream interface.
 A duplex stream in node represents two event emitters, objects
that publish events in Node.js. 

The two event emitters that make up duplex streams are readable streams and
writable streams

*/

var net = require('net');
var server = net.createServer(connectionListener);
server.listen(8181, '127.0.0.1');

function connectionListener(conn) {
	console.log('new client connected');
	//greet the client
	conn.write('hello');
	// read what the client has to say and respond
	conn.on('readable', function() {
	var data = JSON.parse(this.read());
	if (data.name) {
	this.write('hello ' + data.name);
	}
});
//handle errors
conn.on('error', function(e) {
console.log('' + e);
});
}