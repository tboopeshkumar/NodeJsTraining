function concat(a, b, callback){  
     setTimeout(function(){     
        var r = a + b    
        callback(r)  
   }, 50)
 }  

function upper(a, callback){   setTimeout(function(){
     var r = a.toUpperCase()        
    callback (r)  
 }, 50) }  

function decor(a, callback){   setTimeout(function(){
     var r = '*' + a + '*'     
     callback (r)  
     }, 0)
 } 


// invoke now
let result=''
concat('hello', 'Node', r1 => {         
     upper(r1, r2 => {        
           decor(r2, r3 => {           
               console.log(result, r3)          
                    //*HELLONODE*        
         })  
    })
 })
