setInterval(() => console.log('Downloading ......'), 1000) 
setInterval(() => console.log('Uploading.......'), 1000)  
console.log('starting') 
