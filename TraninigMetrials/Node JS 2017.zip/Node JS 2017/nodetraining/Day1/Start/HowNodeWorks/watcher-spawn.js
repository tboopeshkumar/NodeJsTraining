﻿"use strict";
const fs = require('fs'),
spawn = require('child_process').spawn,
filename = process.argv[2];

if (!filename) {
    throw Error("A file to watch must be specified!");
}

fs.watch(filename, function () {
    let ls = spawn('ls', ['-lh', filename]);
    ls.stdout.pipe(process.stdout);
});

console.log("Now watching " + filename + " for changes...");

/*
$ node --harmony watcher-spawn.js target.txt
Now watching target.txt for changes...

If you go to a different console and touch the target file,  observe output

*/