﻿c:\start>node
>console.log("hello node js");

>var x=10;

> x

>var fn= function(name){
    ... console.log("hi"+name);
    ...}
>fn();

>var http=require('http');
>http

>'Murthy'.substring(2,4);

>var d= new Date();
>d