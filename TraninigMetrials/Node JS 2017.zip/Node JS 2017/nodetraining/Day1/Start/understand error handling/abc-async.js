
function c () {
  b();
};

function b () {
  a();
};


//The provided callback function actually operates within its own entirely new context and scope!
function a () {
  setTimeout(function () {
      throw new Error('Oh... error');
      console.log(" i am not executed at all")
  }, 100);
};

c();
