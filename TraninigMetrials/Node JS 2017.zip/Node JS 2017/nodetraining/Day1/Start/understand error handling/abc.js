// synch call
function c () {
  b();
};

function b () {
  a();
};

function a () {
  throw new Error('oh error');
};

c();
