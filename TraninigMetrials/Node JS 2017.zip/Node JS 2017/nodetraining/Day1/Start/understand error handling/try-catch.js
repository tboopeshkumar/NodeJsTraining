
try {
    setTimeout(function () {
        throw new Error('oh.... error');
        console.log(" I am not at all executed");
    }, 10);
} catch (e) { console.log("In  catch block ... u can not see me"+e.message); }

console.log("hello .... I am always seen ")


//The provided callback function actually operates
//within its own entirely new context and scope!
