﻿/* 
for instellisence :
 Preferences- package control - install package - sublimecodeintel

Nodejs 'intellisense' is available via SublimeCodeIntel.


Install node
c:\> node -v

c:\> npm -v

Node modules global path 

C:\Users\%USERNAME%\AppData\Roaming\npm\node_modules
*/



console.log("welcome to Node js world");

// node start.js

// for sublime text to enbale tool-nodejs - run  etc 
//git clone https://github.com/tanepiper/SublimeText-Nodejs "%APPDATA%\Sublime Text 3\Packages\Nodejs"`
