﻿//Node.js global objects available in all modules. 

/*

global

__filename
The __filename represents the filename of the code being executed.
This is the resolved absolute path of this code file.  (two Underscores)

__dirname
The __dirname represents the name of the directory that the currently executing script resides in.

setTimeout(cb, ms)
setInterval()
console : used to print to stdou and stderr

require() : local to each module
require.resolve():   to resolve the file name of a module
module : a reference to the current module
exports: shortcutt for module.exports


processs : 
   exit, beforeExit, uncaughtException    (events)
   env : the user environment    
   stdout, stderr, stdin
   nextTick(): once the currrent eventloop complete , call a callback function
*/

// working with console

console.log('console usage in Node.js');
window.console.log("I am not going to work");//error  window is not defined
global.console.info('console.info writes the', 'same as console.log');
console.error('same as console.log but writes to stderr');
console.warn('same as console.err');

var h = 'hello';
console.trace(h);
//=================================================


console.log(__filename);  // see the output  full path with filename
console.log(__dirname);

function display() {
    console.log("Welcome to global objects");
}

// Now call above function after 2 seconds
var t = setTimeout(display, 2000);

//clearTimeout(t);
setInterval(display, 2000);


function print(var_name) {
    console.log(global[var_name]);
}

global.pet = "cat";
print("pet"); // prints cat
print("fruit"); // prints undefined