var a = 0;
function init() {
  a = 1;
}
function incr() {
  var a = a + 1;    
}
init();
console.log('a before: %d', a);
incr();
console.log('a after: %d', a);









// debug (run, cont , next, setBrakpoint, clearBreakpoint,watch,kill,restart....)
/*
>node debug debugapp.js
debug>help
debug>list(2)
debug>setBreakpoint(7)
debug>cont
debug>next
debug>repl
>a
>ctrl+c to exit


// with node inspector
>npm install -g node-inspector
>node-inspector  &

This sends the node-inspector process to the background.
Open Chrome and type :  http://localhost:8080/debug

open another command prompt/terminal and type
>node  --debug-brk   debugapp.js

Goto chrome and refresh to see the debugapp.js code
now you can set break point and run  
*/


// Node.js runs on Google�s V8, which has a built-in debugging mechanism.
//  Node.js allows you to   debug the source utilizing this tool. 

/**
* Debugging

tell the V8 debug mechanism to pause execution of your
program. This process begins by starting your Node.js application with the �debug� flag.


$ npm install -g node-inspector
$ node-inspector
Node Inspector v0.3.1
info - socket.io started
Visit http://127.0.0.1:8080/debug?port=5858 to start debugging.

Beginning Node Inspection by Creating a Server
$ node --debug  file.js
debugger listening on port 5858
*/
var http = require('http'),
mod = require('./myutility.js');
server = http.createServer(function (req, res) {
    if (req.url === '/') {
        debugger;
        mod.doSomething(function (err, data) {
            if (err) res.end('an error occured');
            res.end(JSON.stringify(data));
        });
    } else {
        res.end('404');
    }
});
server.listen(8080);

/*  c:..> node debug debugging.js
< debugger listening on port 5858
connecting... ok
break in debugging.js:5
3 
4
5 var http = require('http'),
6 mod = require('./myutility.js');
7
debug>
*/

/*
  debug> watch('req.url')  // watch the req.url

  debug> watchers
0: req.url = "<error>"

// Set breakpoint in line 21
debug> sb(21)
debug> sb('myutility.js', 5)    // set breakpoint in another file

debug> s    // for step mode execution
debug>c   for continue
debug> n   //  next
debug> o  // step out

*/
