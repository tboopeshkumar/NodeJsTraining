
//private data
var name="Kavitha";

//private function
function log(msg){
    console.log("Logged -  "+msg)
}
/*
 module.exports = (who) => {  
      log(who)
      console.log(`Hello ${who}`)
     } 
*/

//We can export classes, functions or objects
 module.exports = {     
     name: 'Murthy',  
     surname: 'Sri',  
     getFullName: function(){
         log(name +'  accessed this module on '+new Date());  //kavitha accessed .......
          return `${this.name} ${this.surname}`
         }
     } 

//private




