/*

module.exports is a global object that is exported to the caller using the require function.

 The require function returns an object that references module.exports of that file. 

Everything defined inside a module is private and doesn’t pollute the global scope 
except what is assigned to module.exports, and when a module is required,
 it is cached for better performance. 

This means the subsequent requires to the same module receive the same instance 


*/

//var greet = require('./mymodule') 
//greet('Srirama Murthy') 

var user = require('./mymodule');// will come from cache
 console.log(user.name); // Murthy
 console.log(user.getFullName()); //Murthy sri

//user.log("logged info''); can not access as it is private

var calc = require('./calculator');
console.log("Result of add function :"+calc.add(10,20));
calc.perform();
 
//Test constructor Module
var ABCClass = require('./constructormodule');
var obj = new ABCClass();
obj.functionA(1, 2);