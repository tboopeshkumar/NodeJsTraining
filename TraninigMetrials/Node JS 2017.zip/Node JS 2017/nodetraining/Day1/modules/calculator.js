var calculate = function (numA, numB) {
    return numA * numB + 10 * numB;
}

var add = function (numA, numB) {
    return numA + numB;
}
var perform = function () {
    console.log("I am perform function in module");
}
exports.calculate = calculate;
exports.add = add;
exports.perform = perform;