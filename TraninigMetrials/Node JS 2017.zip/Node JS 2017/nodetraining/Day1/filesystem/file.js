const fs = require('fs') 
// Asynchronous - Opening File
console.log("Going to open file!");
fs.open('file.js', 'r+', function (err, fd) {
    if (err) {
        return console.error(err);
    }
    console.log("File opened successfully!");
});

 const watcher = fs.watch('test') 
watcher.on('change', function(event, filename) {  
     console.log(`${event} on file ${filename}`) 
    })

