/**
* Reading a file with args
*/
var fs = require('fs'), args;
args = process.argv.splice(2);// concert to array

args.forEach(function (arg) {
    //async read
    fs.readFile(arg, 'utf8', function (err, data) {
        if (err) console.log(err);
        console.log(data);
    });
});
                                                                      
// To run    : node readingfile.js  points.txt








// read with sync and buffer
var handle = fs.openSync('info.txt', 'r');
var buf = new Buffer(100000);
var read = fs.readSync(handle, buf, 0, 10000, null);
console.log(buf.toString('utf8', 0, read));
fs.closeSync(handle);