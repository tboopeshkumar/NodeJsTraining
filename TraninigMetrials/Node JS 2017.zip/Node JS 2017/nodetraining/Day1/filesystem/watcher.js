/**
* Watching files for modifications
*/
var fs = require('fs'),
path = './points.txt';
// fs.watchFile(...)
fs.watch(path, function(event, filename) {
	if (filename) {
	console.log(filename s+ ' : ' + event);
	} else {
//Macs don't pass the filename
	console.log(path + ' : ' + event);
   }
});