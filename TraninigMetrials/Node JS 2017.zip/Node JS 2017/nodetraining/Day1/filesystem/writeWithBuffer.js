﻿// Reading file content with buffer asynchronously
/*
var fs = require('fs');
fs.open(
'info.txt', 'r',
function (err, handle) { // after file successfully opened , handle is available - async  code
    var buf = new Buffer(100000);
    fs.read(
    handle, buf, 0, 100000, null,
    function (err, length) {
        console.log(buf.toString('utf8', 0, length));
        fs.close(handle, function () {  });
    }
    );
});

flow of execution
■ Check and validate parameters.
■ Tell the Node.js core to queue the call to the appropriate function  and to notify (call)
   the provided callback function when there is a result.
■ Return to the caller.
*/

// Sync writing
var fs = require('fs');

var BUFFER_SIZE = 1000000;

function copy_file_sync(src, dest) {
    var read_so_far, fdsrc, fddest, read;
    var buff = new Buffer(BUFFER_SIZE);
    fdsrc = fs.openSync(src, 'r');
    fddest = fs.openSync(dest, 'w');
    read_so_far = 0;
    do {
        read = fs.readSync(fdsrc, buff, 0, BUFFER_SIZE, read_so_far);
        fs.writeSync(fddest, buff, 0, read);
        read_so_far += read;
    } while (read > 0);

    fs.closeSync(fdsrc);
    fs.closeSync(fddest);

    return fs.unlinkSync(src);// remove the source file after copying
}

if (process.argv.length != 4) {
    console.log("Usage: " + path.basename(process.argv[1], '.js')
    + " [src_file] [dest_file]");
} else {
    try {
        copy_file_sync(process.argv[2], process.argv[3]);
    } catch (e) {
        console.log("Error copying file:");
        console.log(e);
        process.exit(-1);
    }
    console.log("1 file copied.");
}