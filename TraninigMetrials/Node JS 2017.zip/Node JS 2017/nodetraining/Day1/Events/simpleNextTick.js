﻿// Process is global object
console.log(1);
process.nextTick(function () {
    console.log(3);
});
console.log(2);

// output  1 2 3