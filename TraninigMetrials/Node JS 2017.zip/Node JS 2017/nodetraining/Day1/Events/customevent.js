/**
* Adding Event Listeners to Custom Events and System Events

Custom Events
*/
var events = require('events'),
     emitter = new events.EventEmitter();

function doATask(status) {
	if (status === 'success') {
		emitter.emit('taskSuccess'); // Raise Specific event
	} else if (status === 'fail') {
		emitter.emit('taskFail');
   }
	// This event passes arguments to detail status
	emitter.emit('taskComplete', 'complete', status); // raise event with type and scope
  }

emitter.on('taskSuccess', function() {// subscribe to event
	console.log('task success!');
});
emitter.on('taskFail', function() {
	console.log('task fail');
});
// register listener for task complete
emitter.on('taskComplete', function(type, status) {
	console.log('the task is ', type, ' with status ', status);
});

// call task with success status
setTimeout(doATask, 2e3, 'success');
// set task to fail
setTimeout(doATask, 4e3, 'fail');
//----------------------------------------------------------
/*
     Node is event driven model with non blocking
     events is core module
     eventEmitter object is responsible for firing events
     Built in events for ex in stream :  data, close,end ,finish
     we can create custom event with emit() 
     subscribe built-in or custom events with emitter.on()

     Create custom events in custom modules and consume it in 
     other modules

     running under eventloop of V8
*/



/*
Emitting an Event on the Node.js Process
/* Module.js file */

/*
var myMod = module.exports = {
	emitEvent: function() {
	process.emit('globalEvent');
	}
};

*/

/*
// Global event
var ext = require('./module.js');
	process.on('globalEvent', function() {
	console.log('global event');
});
ext.emitEvent();
*/


/*
Event Listening from an External Module
/**
* External Module 
*/
/*
module.exports = function(emitter) {
	emitter.on('custom', function() {
	console.log('Hurry .. got event');
});
};
*/
