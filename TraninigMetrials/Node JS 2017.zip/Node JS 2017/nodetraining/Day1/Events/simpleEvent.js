﻿var EventEmitter = require('events').EventEmitter,
    a = new EventEmitter;

a.on('event', function () {
    console.log('event called');
});

a.emit('event');


/*
// OOP's event

var EventEmitter1 = process.EventEmitter, 
   MyClass = function () { };
//Extending EventEmitter

MyClass.prototype.__proto__ = EventEmitter.prototype;

var a = new MyClass;
a.on('some event', function () {
    // do something
});
*/