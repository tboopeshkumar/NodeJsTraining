var app=require('express')();
var http=require('http').server(app);
var mysql=require('mysql');
var bodyParser=require('body-parser');
var connection=mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'',
	database:'books'
});
app.use(bodyParser.urlencoded({
	extended:false
}));
app.use(bodyParser.json());
app.get('/',function(req,res){
	var data={
		  "Data":""
	};
	data["Data"]="Welcome to Book store";
	res.json(data);
});

app.get('/book',function(req,res){
   var data={
   	   "error":1,
   	   "Books":""
   }
});

connection.query
("SELECT * from book",
	function(err,rows,fiels){
	if(rows.length !=0){
		  data["error"]=0;
		  data["Books"]=rows;
		  res.json(data);
	}
	else
	{
	data["Books"]='No books Found';
	res.json(data);
	}
  });

});

app.post('/book',function(req,res){
   var Bookname=req.body.bookname;
   var Authorname=req.body.authorname;
   var Price=req.body.price;
   var data={
   	   "error":1,
   	   "Books":""
   };
   if(!!Bookname && !!Authornae !! !!Price){
  connection.query("INSERT into book values ('',?,?,?)",
  	  [Bookname,AuthorName,Price],function(err,rows,fields){
if(!!err){
	data["Books"]="Error adding data";
   }
   else {
   	data["error"]=0;
   	data["Books"]="Book added successfully";
   }
  res.json(data);
  	  }
   });
  }
});
    else{
	  data['Books']="Please provide all required fields";
	  res.json(data);
      }
});




app.put('/book',function(req,res){
   var Bookname=req.body.bookname;
   var Authorname=req.body.authorname;
   var Price=req.body.price;
   var data={
   	   "error":1,
   	   "Books":""
   };
   if(!!Bookname && !!Authornae !! !!Price){
  connection.query("update book set BookName=?,AuthorName=? ,Price=? where id=?",[Bookname,Authorname,Price,Id],function(err,rows,fields){
if(!!err){
	data["Books"]="Error updating data";
   }
   else {
   	data["error"]=0;
   	data["Books"]="Book updated successfully";
   }
  res.json(data);
  	  }
   });
  }
});
    else{
	  data['Books']="Please provide all required fields";
	  res.json(data);
      }
});


app.delete('/book',function(req,res){
   var Id=req.body.id;
   var data={
   	"error":1,
   	"Books":""
   };
   if(!!Id){
   	connection.query("Delete from book where id=?".[Id],function(err,rows,fields){
     if(!!err){
     	data["Books"]="Error Deleting data";
     }
     else{
     	data["error"]=0;
     	data["Books"]="Deleted book successfully";
     }
     res.json(data);
   	});
   	else
   	{
   		data["Books"]="Please provide required data (Id)";
   		res.json(data);
   	}
   
});

