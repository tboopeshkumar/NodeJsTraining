// Model ... get it from mongo db or mysql
// write create/update/delete/read logic here by connecting to mongo db
var thelist = function () {
  var objJson = {
    "GroupName": "D",
    "count": 4,
    "teams": [{
      "country": "England"
    }, {
      "country": "Australia"
    }, {
      "country": "Sweden"
    }, {
      "country": "India"
    }]
  };
  return objJson;
};
exports.teamlist = thelist(); 