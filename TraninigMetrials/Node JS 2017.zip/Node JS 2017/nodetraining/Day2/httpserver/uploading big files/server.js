﻿/*
The HTTP server with formidable integrated to handle file uploading.

This is a fantastic feature for any application expecting large uploads, 
and it’s a task that Node is well suited for. 

By using the WebSocket protocol, for instance, or a real-time module like Socket.IO, it would be possible
in just a few lines of code
*/

var http = require('http');

var formidable = require('formidable');


var server = http.createServer(function (req, res) {
    switch (req.method) {
        case 'GET':
            show(req, res);
            break;
        case 'POST':
            upload(req, res);
            break;
    }
});
// server html form with file input
function show(req, res) {
    var html = ''
    + '<form method="post" action="/" enctype="multipart/form-data">'
    + '<p>Name : <input type="text" name="name" /></p>'
    + '<p><input type="file" name="file" /></p>'
    + '<p><input type="submit" value="Upload big file" /></p>'
    + '</form>';
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Length', Buffer.byteLength(html));
    res.end(html);
}
/*
formbidable module:

1 Install formidable through npm.  (npm install formidable)
2 Create an IncomingForm instance. 
3 Call form.parse() with the HTTP request object.
4 Listen for form events field, file, and end.
5 Use formidable’s high-level API.
*/

function upload(req, res) {
    // upload logic
    if (!isFormData(req)) {
        res.statusCode = 400;
        res.end('Bad Request: expecting multipart/form-data');
        return;
    }
    /*
    initialize a new formidable.IncomingForm form and then issue the form.parse(req) method call,
where req is the request object. This allows formidable to access the request’s data events for parsing:

a file event is issued when a file has been received and processed, and field is issued on the complete
receipt of a field.
    */

    // Create an IncomingForm instance. 
    var form = new formidable.IncomingForm();

   // event fired on complete receipt of field
    form.on('field', function (field, value) {
        console.log('Field : '+field);
        console.log('Field value '+value);
    });
    // event fired when file received and processed (write content into file here)
    form.on('file', function (name, file) {
        console.log('name :' + name);
        console.log('Complete information about file is below : ')
        console.log(file);
        
    });

    form.on('end', function () {
        res.end('upload complete!');
    });

    form.on('progress', function (bytesReceived, bytesExpected) {
        var percent = Math.floor(bytesReceived / bytesExpected * 100);
        console.log("progress : "+percent);
    });
    //Call form.parse() with the HTTP request object.
    form.parse(req);
}

// helper method to check multipart form data or not
function isFormData(req) {
    var type = req.headers['content-type'] || '';
    return 0 == type.indexOf('multipart/form-data');
}

server.listen(3000);
console.log("server running on port 3000")
