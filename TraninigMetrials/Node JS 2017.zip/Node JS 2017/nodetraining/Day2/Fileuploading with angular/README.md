1. npm install
2. node app.js.
   or gulp
3.  Open http://localhost:3000in your browser
4. select files and upload