var socketServer = require('./socketServer');
socketServer.init(8080, 9000);

// webserver listening on 8080 & web socket at 9000
console.log("http server running on localhost:8080")